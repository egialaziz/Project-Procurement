/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Remove the webpack configuration as it's causing conflicts
  // Path aliases are handled by jsconfig.json
}

module.exports = nextConfig
