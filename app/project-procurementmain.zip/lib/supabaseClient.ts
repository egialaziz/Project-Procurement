import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://placeholder.supabase.co"
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "placeholder-key"

// Create a mock client if environment variables are not set
const isConfigured = process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

export const supabase = isConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : {
      from: () => ({
        select: () => ({
          order: () => Promise.resolve({ data: mockData, error: null }),
        }),
        insert: () => Promise.resolve({ error: null }),
      }),
    }

// Mock data for demonstration when Supabase is not configured
const mockData = [
  {
    id: 1,
    no: 1,
    photo: "/placeholder.svg?height=100&width=100",
    spesifikasi: "Laptop Dell Inspiron 15 3000",
    minimum_pemesanan: "1 unit",
    harga_minimum: 8500000,
    po_terbit: "2024-01-15",
    vendor: "PT Tech Solutions",
    jenis: "Electronics",
    created_at: "2024-01-01T00:00:00Z",
  },
  {
    id: 2,
    no: 2,
    photo: "/placeholder.svg?height=100&width=100",
    spesifikasi: "Kursi Kantor Ergonomis",
    minimum_pemesanan: "5 unit",
    harga_minimum: 1200000,
    po_terbit: "2024-01-20",
    vendor: "PT Furniture Indo",
    jenis: "Furniture",
    created_at: "2024-01-02T00:00:00Z",
  },
  {
    id: 3,
    no: 3,
    photo: "/placeholder.svg?height=100&width=100",
    spesifikasi: "Printer Canon PIXMA G2010",
    minimum_pemesanan: "2 unit",
    harga_minimum: 2100000,
    po_terbit: "2024-01-25",
    vendor: "PT Office Equipment",
    jenis: "Electronics",
    created_at: "2024-01-03T00:00:00Z",
  },
  {
    id: 4,
    no: 4,
    photo: "/placeholder.svg?height=100&width=100",
    spesifikasi: "Meja Kerja Kayu Jati 120x60cm",
    minimum_pemesanan: "3 unit",
    harga_minimum: 1800000,
    po_terbit: "2024-02-01",
    vendor: "PT Furniture Indo",
    jenis: "Furniture",
    created_at: "2024-01-04T00:00:00Z",
  },
  {
    id: 5,
    no: 5,
    photo: "/placeholder.svg?height=100&width=100",
    spesifikasi: "Proyektor Epson EB-X41",
    minimum_pemesanan: "1 unit",
    harga_minimum: 4500000,
    po_terbit: "2024-02-05",
    vendor: "PT Tech Solutions",
    jenis: "Electronics",
    created_at: "2024-01-05T00:00:00Z",
  },
]

export const isSupabaseConfigured = isConfigured
